words = open("file.txt")
words.readlines
Count = 0

for line in words:
	main_count = line.split(' ')
	count =+ len(main_count)
words.close()
print  ('number of words in file: ' , count)