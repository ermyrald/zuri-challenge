num1 = 5
num2 = 7
total = num1 + num2
print (total)