print ('Choose an operation')
print ('Add')
print ('Mul')
print ('Sub')
print ('Div')
operation =  input('[+] Choose an operation: ')

number1 = input('please input first number:')
number2 = input('please input first number:')



if operation == ("add"):
	print(number1 + number2)

	
elif operation == ('mul'):
	print(number1 * number2)


elif operation == ('sub'):
	print(number1 - number2)


elif operation == ('div'):
	print(number1 / number2)


elif operation == ('mul'):
	print(number1 % number2)

else:
	print ('Invalid entries supplied')